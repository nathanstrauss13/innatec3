import os, json, time, hashlib
from pathlib import Path
from urllib.parse import urlparse
import pandas as pd

ROOT = Path(__file__).resolve().parents[1]
CONFIG = ROOT / "config"
DATA = ROOT / "data"
OUTPUT = ROOT / "output"

def env(key, default=None):
    return os.environ.get(key, default)

def load_env():
    dotenv_path = CONFIG / ".env"
    if dotenv_path.exists():
        for line in dotenv_path.read_text().splitlines():
            if not line.strip() or line.strip().startswith("#"): 
                continue
            k, _, v = line.partition("=")
            os.environ[k.strip()] = v.strip()

def domain_to_outlet(domain, mapping):
    d = domain.lower().replace("www.", "")
    return mapping.get(d, d)

def extract_domain(url):
    try:
        return urlparse(url).netloc
    except Exception:
        return ""

def hash_row(row: dict) -> str:
    m = hashlib.sha256()
    m.update(("|".join(str(row.get(k,\"\")) for k in sorted(row.keys()))).encode(\"utf-8\"))
    return m.hexdigest()

def call_perplexity(query: str):
    key = env("PPLX_API_KEY")
    if not key:
        return []
    import requests
    headers = {"Authorization": f"Bearer {key}", "Content-Type": "application/json"}
    payload = {"model": "sonar-pro", "messages": [{"role":"user","content":query}]}
    r = requests.post("https://api.perplexity.ai/chat/completions", headers=headers, json=payload, timeout=60)
    r.raise_for_status()
    data = r.json()
    citations = []
    # Try to collect citations generically
    try:
        urls = []
        if isinstance(data, dict):
            if "citations" in data:
                urls = data["citations"]
            # choices[0].message.metadata.citations or web_search_sources
            if data.get("choices"):
                meta = data["choices"][0].get("message", {}).get("metadata", {})
                urls = meta.get("citations", []) or meta.get("web_search_sources", urls)
        for u in urls:
            if isinstance(u, dict):
                url = u.get("url") or u.get("source") or ""
            else:
                url = str(u)
            if url:
                citations.append(url)
    except Exception:
        pass
    return citations

def call_openai_list_outlets(query: str):
    key = env("OPENAI_API_KEY")
    if not key:
        return []
    import requests, re, json as pyjson
    cfg = json.load(open(CONFIG/"prompts.json"))
    system = cfg["openai"]["system"]
    template = cfg["openai"]["user_template"]
    user = template.format(q=query)
    headers = {"Authorization": f"Bearer {key}", "Content-Type": "application/json"}
    payload = {
        "model": "gpt-4o-mini",
        "messages": [{"role":"system","content":system},{"role":"user","content":user}]
    }
    r = requests.post("https://api.openai.com/v1/chat/completions", headers=headers, json=payload, timeout=60)
    r.raise_for_status()
    txt = r.json()["choices"][0]["message"]["content"]
    m = re.search(r"\\[.*\\]", txt, re.S)
    if not m:
        return []
    try:
        arr = pyjson.loads(m.group(0))
        return [str(x) for x in arr if isinstance(x, (str,))]
    except Exception:
        return []

def run():
    load_env()
    mapping = json.load(open(CONFIG/"outlet_domain_map.json"))
    queries = pd.read_csv(DATA/"queries.csv")["query"].dropna().tolist()

    rows = []
    for q in queries:
        # Perplexity (explicit citations where available)
        urls = call_perplexity(q)
        for u in urls:
            rows.append({"provider":"perplexity","query":q,"url":u})

        # OpenAI (simulated outlet names)
        outlets = call_openai_list_outlets(q)
        for name in outlets:
            rows.append({"provider":"openai_simulated","query":q,"outlet":name})

        time.sleep(0.25)

    df = pd.DataFrame(rows)

    if not df.empty:
        if "url" in df.columns:
            df["domain"] = df["url"].fillna("").apply(lambda x: urlparse(x).netloc if isinstance(x,str) else "")
            df["outlet"] = df.apply(lambda r: r.get("outlet") or domain_to_outlet(r.get("domain",""), mapping), axis=1)
        df = df.drop_duplicates()

    OUTPUT.mkdir(parents=True, exist_ok=True)
    df.to_csv(OUTPUT/"citations_raw.csv", index=False)

    if df.empty:
        agg = pd.DataFrame(columns=["outlet","count"])
    else:
        agg = df.groupby("outlet").size().reset_index(name="count").sort_values("count", ascending=False)
    agg.to_csv(OUTPUT/"outlet_counts.csv", index=False)

    print("Wrote:", OUTPUT/"citations_raw.csv", OUTPUT/"outlet_counts.csv")

if __name__ == "__main__":
    run()