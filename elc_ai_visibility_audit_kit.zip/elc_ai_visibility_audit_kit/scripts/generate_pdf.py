from reportlab.lib.pagesizes import LETTER
from reportlab.lib import colors
from reportlab.platypus import SimpleDocTemplate, Paragraph, Spacer, Table, TableStyle
from reportlab.lib.styles import getSampleStyleSheet
from pathlib import Path
import pandas as pd

ROOT = Path(__file__).resolve().parents[1]
OUTPUT = ROOT/"output"

def build_pdf():
    styles = getSampleStyleSheet()
    title_style = styles['Title']
    h2 = styles['Heading2']
    body = styles['BodyText']

    doc = SimpleDocTemplate(str(OUTPUT/"ELC_AI_Visibility_Audit.pdf"), pagesize=LETTER)
    els = []

    els.append(Paragraph("AI Visibility Audit — Estée Lauder Companies", title_style))
    els.append(Spacer(1, 12))
    els.append(Paragraph("“The outlets AI trusts most are the ones you need to win.”", h2))
    els.append(Spacer(1, 24))

    els.append(Paragraph("Executive Summary", h2))
    els.append(Paragraph("This report aggregates citations (where available) and likely outlets (signal-only where citations are not exposed) to identify which publishers shape AI-generated answers for Estée Lauder Companies (ELC).", body))
    els.append(Spacer(1, 12))

    counts_path = OUTPUT/"outlet_counts.csv"
    if counts_path.exists():
        df = pd.read_csv(counts_path).head(15)
        els.append(Paragraph("Top Influential Outlets (Aggregated)", h2))
        data = [["Outlet","Relative Frequency"]] + df.values.tolist()
        tbl = Table(data, hAlign="LEFT")
        tbl.setStyle(TableStyle([
            ("BACKGROUND", (0,0), (-1,0), colors.HexColor("#d9d9d9")),
            ("GRID", (0,0), (-1,-1), 0.5, colors.grey),
            ("FONTNAME", (0,0), (-1,0), "Helvetica-Bold")
        ]))
        els.append(tbl)
        els.append(Spacer(1, 12))
    else:
        els.append(Paragraph("No outlet data found. Run scripts/run_audit.py first.", body))

    els.append(Paragraph("Recommendations (Sample)", h2))
    els.append(Paragraph("1) Prioritize outreach to the top 5 outlets above. 2) Close gaps in outlets citing competitors. 3) Place stories reinforcing leadership, innovation, and sustainability narratives. 4) Re-run quarterly to track gains.", body))

    doc.build(els)

if __name__ == "__main__":
    OUTPUT.mkdir(parents=True, exist_ok=True)
    build_pdf()