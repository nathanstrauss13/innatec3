# Estée Lauder Companies — AI Visibility Audit (Report Factory Kit)

This kit lets you run a *pay‑per‑report* style AI Visibility Audit for **Estée Lauder Companies (ELC)** as a white‑label deliverable.
It is designed for fast execution: drop API keys in `.env`, run `python scripts/run_audit.py`, then generate a PDF with `python scripts/generate_pdf.py`.

## What you'll get
- Aggregated **AI citation data** across multiple models (where supported), normalized to publisher names.
- CSVs suitable for analysis and charting.
- A branded **PDF report** (white‑label friendly).

## Quick start
1. Copy `config/.env.example` to `config/.env` and fill in keys you have.
2. (Optional) Edit `config/brands.json` and `data/queries.csv` if you want different competitors or prompts.
3. From the project root, run:
   ```bash
   python3 scripts/run_audit.py
   python3 scripts/generate_pdf.py
   ```
4. Your report will appear at `output/ELC_AI_Visibility_Audit.pdf`.

## Notes
- APIs differ in whether they expose **citations**. Perplexity exposes sources; Bing (Chat) and Google Overviews do not have public, stable chat APIs for citations. OpenAI/Anthropic won't reliably return sources; we prompt them to list likely outlets (signal only).
- The pipeline gracefully degrades if a key isn't provided — it will skip that provider and still build a report from available data.
- This kit uses widely available Python libraries only; charts in the PDF are simple tables to avoid extra dependencies.